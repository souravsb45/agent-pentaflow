"""
Simple runner script for Agent PentaFlow (simulation).
"""
import argparse
from src.main.orchestrator.interactive_research_agent import InteractiveResearchAgent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", required=True)
    parser.add_argument("--dataset", default=None)
    args = parser.parse_args()

    agent = InteractiveResearchAgent()
    result = agent.run(args.topic, args.dataset)
    print("Report generated at:", result["report_path"])
    if result.get("visuals"):
        print("Visuals:", result["visuals"])

if __name__ == "__main__":
    main()
