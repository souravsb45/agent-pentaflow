"""
Basic test to simulate pipeline run.
"""
import os
from src.main.orchestrator.interactive_research_agent import InteractiveResearchAgent

def test_run_pipeline(tmp_path):
    agent = InteractiveResearchAgent()
    out = agent.run("Test Topic")
    assert "report_path" in out
    assert os.path.exists(out["report_path"])
