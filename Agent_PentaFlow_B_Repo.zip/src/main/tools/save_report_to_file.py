"""
save_report_to_file.py
Simple utility to save report text to a Markdown file.
"""
from pathlib import Path

def save_report_to_file(report_text, out_path="outputs/report.md"):
    p = Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(report_text, encoding="utf-8")
    return str(p.resolve())
