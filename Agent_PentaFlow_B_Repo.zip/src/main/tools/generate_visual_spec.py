"""
generate_visual_spec.py
Creates JSON-like visualization specs based on inspected data.
"""
def generate_visual_spec(inspect_result):
    specs = []
    num = inspect_result.get("numeric", {})
    for i,(col,meta) in enumerate(num.items()):
        specs.append({"type": "line" if i==0 else "bar", "column": col, "meta": meta})
    return {"specs": specs}
