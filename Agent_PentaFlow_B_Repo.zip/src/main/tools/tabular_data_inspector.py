"""
tabular_data_inspector.py
Simple CSV inspector that returns basic stats (moderate).
"""
import csv
from statistics import mean

def inspect_csv(path):
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    if not rows:
        return {"rows": 0}
    numeric = {}
    for k in rows[0].keys():
        vals = []
        for r in rows:
            try:
                vals.append(float(r[k]))
            except:
                pass
        if vals:
            numeric[k] = {"count": len(vals), "mean": mean(vals)}
    return {"rows": len(rows), "numeric": numeric}
