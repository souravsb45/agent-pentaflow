"""
interactive_research_agent.py
Orchestrator for Agent PentaFlow (moderate template)
"""
from src.main.agents.research_explorer import ResearchExplorer
from src.main.agents.outline_designer import OutlineDesigner
from src.main.agents.structured_report_writer import StructuredReportWriter
from src.main.agents.chart_creator_agent import ChartCreatorAgent
from src.main.agents.report_editor import ReportEditor
from src.main.tools.save_report_to_file import save_report_to_file

class InteractiveResearchAgent:
    def __init__(self, config=None):
        self.config = config or {}
        self.researcher = ResearchExplorer()
        self.outliner = OutlineDesigner()
        self.writer = StructuredReportWriter()
        self.charts = ChartCreatorAgent()
        self.editor = ReportEditor()

    def run(self, topic, dataset_path=None):
        # Stage 1: Research exploration
        research_ctx = self.researcher.explore(topic)
        # Stage 2: Outline creation
        outline = self.outliner.create_outline(topic, research_ctx)
        # Stage 3: Draft writing
        draft = self.writer.write_report(outline, research_ctx)
        # Stage 4: Visual generation (if dataset)
        visuals = None
        if dataset_path:
            visuals = self.charts.create_visuals(dataset_path)
        # Stage 5: Editing
        final = self.editor.edit(draft, visuals)
        # Export
        path = save_report_to_file(final, f"outputs/{topic.replace(' ','_')}.md")
        return {"report_path": path, "visuals": visuals}
