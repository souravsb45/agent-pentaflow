"""
chart_creator_agent.py
Analyzes a CSV (or similar) and generates simple chart specifications.
"""
import csv
from collections import defaultdict

class ChartCreatorAgent:
    def __init__(self):
        pass

    def create_visuals(self, dataset_path):
        # Very simple CSV reader that inspects numeric columns and returns basic specs
        try:
            with open(dataset_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
            if not rows:
                return {"error": "empty dataset"}
            # detect numeric-like columns
            numeric_cols = []
            for k in rows[0].keys():
                try:
                    float(rows[0][k])
                    numeric_cols.append(k)
                except Exception:
                    pass
            specs = []
            for col in numeric_cols[:3]:
                specs.append({"type": "bar", "column": col, "description": f"Bar chart for {col}"})
            return {"specs": specs, "rows": len(rows)}
        except FileNotFoundError:
            return {"error": "file not found"}
