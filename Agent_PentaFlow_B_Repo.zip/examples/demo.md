# Demo: Running Agent PentaFlow

This demo shows how the system runs in a simplified way.

```bash
python scripts/run_pipeline.py --topic "Impact of Renewable Energy"
```

The script will produce a Markdown report under `outputs/`.
