# Agent PentaFlow — Architecture

Agent PentaFlow is centered around an orchestrator agent (`interactive_research_agent`) which delegates work to specialized sub-agents:

- research_explorer: gathers and summarizes background research
- outline_designer: creates a logical and complete outline
- structured_report_writer: converts outlines into full drafts
- chart_creator_agent: generates chart specs from tabular data
- report_editor: polishes and finalizes the document

Tools:
- tabular_data_inspector
- generate_visual_spec
- save_report_to_file

Validation Checkers:
- ResearchScopeValidationChecker
- OutlineFormatChecker
- ReportCompletenessChecker

The system uses LoopAgent-style retry and validation before proceeding from stage to stage.
